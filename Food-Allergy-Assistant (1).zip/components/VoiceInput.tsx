'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';

interface VoiceInputProps {
  onFoodCheck: (ingredients: string) => void;
  selectedAllergies: string[];
  disabled: boolean;
}

export default function VoiceInput({ onFoodCheck, selectedAllergies, disabled }: VoiceInputProps) {
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Initialize Web Speech API
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      console.log('[v0] Speech Recognition API not supported');
      setIsSupported(false);
      return;
    }

    try {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.language = 'en-US';

      recognitionRef.current.onstart = () => {
        console.log('[v0] Voice recognition started');
        setIsListening(true);
        setVoiceError(null);
        setTranscript('');
        setInterimTranscript('');
      };

      recognitionRef.current.onresult = (event: any) => {
        console.log('[v0] Voice result event:', event.results.length);
        let interimText = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          console.log('[v0] Transcript:', transcript, 'isFinal:', event.results[i].isFinal);
          
          if (event.results[i].isFinal) {
            setTranscript((prev) => {
              const updated = prev + transcript + ' ';
              console.log('[v0] Updated final transcript:', updated);
              return updated;
            });
          } else {
            interimText += transcript;
          }
        }
        
        if (interimText) {
          console.log('[v0] Interim transcript:', interimText);
          setInterimTranscript(interimText);
        }
      };

      recognitionRef.current.onend = () => {
        console.log('[v0] Voice recognition ended');
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('[v0] Speech recognition error:', event.error);
        setIsListening(false);
        
        // Map error codes to user-friendly messages
        const errorMessages: Record<string, string> = {
          'no-speech': 'No speech detected. Please try again.',
          'audio-capture': 'No microphone detected. Please check your audio input.',
          'network': 'Network error. Please check your connection.',
          'not-allowed': 'Microphone access was denied. Please allow access.',
          'bad-grammar': 'Error processing speech. Please try again.',
          'service-not-allowed': 'Speech service not available.',
        };
        
        const errorMsg = errorMessages[event.error] || `Error: ${event.error}. Please try again.`;
        console.log('[v0] Error message:', errorMsg);
        setVoiceError(errorMsg);
      };
    } catch (error) {
      console.error('[v0] Failed to initialize Speech Recognition:', error);
      setIsSupported(false);
    }
  }, []);

  const startListening = () => {
    if (!recognitionRef.current) {
      setVoiceError('Speech Recognition not available');
      return;
    }
    
    if (isListening) return;
    
    try {
      console.log('[v0] Starting voice recognition');
      recognitionRef.current.start();
    } catch (error) {
      console.error('[v0] Error starting recognition:', error);
      setVoiceError('Failed to start listening. Please try again.');
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      console.log('[v0] Stopping voice recognition');
      recognitionRef.current.stop();
    }
  };

  const handleSubmit = (text: string) => {
    if (!text.trim()) {
      console.log('[v0] Empty text submitted');
      return;
    }

    console.log('[v0] Submitting voice input:', text);
    onFoodCheck(text);
    setInput('');
    setTranscript('');
    setInterimTranscript('');
  };

  const useTranscript = () => {
    const finalText = transcript.trim();
    if (finalText) {
      handleSubmit(finalText);
    }
  };

  if (!isSupported) {
    return (
      <div className="space-y-3">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-sm text-red-800">
            ⚠️ Your browser doesn't support voice input. Please use text input instead.
          </p>
        </div>
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Type ingredients..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSubmit(input);
              }
            }}
            disabled={disabled}
            className="flex-1 border-2 border-blue-200 focus:border-blue-500"
          />
          <Button
            onClick={() => handleSubmit(input)}
            disabled={disabled || !input.trim()}
            className="bg-green-600 hover:bg-green-700 text-white px-6"
          >
            Check
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Voice Error Message */}
      {voiceError && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-sm text-red-800">❌ {voiceError}</p>
        </div>
      )}

      {/* Voice Controls */}
      <div className="flex gap-2">
        <Button
          onClick={isListening ? stopListening : startListening}
          disabled={disabled}
          className={`flex-1 flex items-center justify-center gap-2 ${
            isListening 
              ? 'bg-red-600 hover:bg-red-700' 
              : 'bg-purple-600 hover:bg-purple-700'
          } text-white`}
        >
          {isListening ? (
            <>
              <Spinner className="size-4" />
              <span>Listening...</span>
            </>
          ) : (
            <>
              <span>🎤</span>
              <span>Start Speaking</span>
            </>
          )}
        </Button>

        {transcript && (
          <Button
            onClick={useTranscript}
            disabled={disabled}
            className="bg-green-600 hover:bg-green-700 text-white px-6"
          >
            Use
          </Button>
        )}
      </div>

      {/* Transcription Display */}
      {(transcript || interimTranscript) && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-1">
          {transcript && (
            <p className="text-sm font-medium text-blue-900">✓ Detected: {transcript}</p>
          )}
          {interimTranscript && !transcript && (
            <p className="text-sm italic text-blue-700">Listening: {interimTranscript}...</p>
          )}
        </div>
      )}

      {/* Fallback Text Input */}
      <div className="space-y-2">
        <label className="text-xs font-medium text-gray-600">Or type manually:</label>
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Type ingredients..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSubmit(input);
              }
            }}
            disabled={disabled || isListening}
            className="flex-1 border-2 border-blue-200 focus:border-blue-500"
          />
          <Button
            onClick={() => handleSubmit(input)}
            disabled={disabled || !input.trim() || isListening}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6"
          >
            Check
          </Button>
        </div>
      </div>

      {/* Info */}
      <p className="text-xs text-gray-500 text-center">
        💡 Tip: Speak clearly and wait for "✓ Detected" to appear before clicking Use.
      </p>
    </div>
  );
}
